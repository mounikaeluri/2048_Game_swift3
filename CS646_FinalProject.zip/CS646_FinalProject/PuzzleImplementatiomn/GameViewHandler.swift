//
//  GameViewHandler.swift
//  PuzzleImplementatiomn
//
//  Created by Mounika Eluri on 12/12/16.
//  Copyright © 2016 Mounika Eluri. All rights reserved.
//


import Foundation
import CoreGraphics
//to handle the game logic in gameviewcontroleer
protocol GameLogicHandlerDelegate {
    func gameLogicHandlerDidAddTile(_ tile: Tile?)
    func gameLogicHandlerDidMoveTile(_ sourceTile: Tile, onTile destinationTile: Tile,completionBlock:  @escaping (Void) -> Void)
    func gameLogicHandlerDidMoveTile(_ tile: Tile, position: Position, completionBlock:  @escaping (Void) -> Void)
    func gameLogicHandlerDidCountPoints(_ points: Int)
    func gameLogicHandlerDidGameOver()
    func gameLogicHandlerDidWinGame()
}

enum ShiftDirections {
    case up, right, down, left
}
//gamelogichandler class
class GameLogicHandler {
    let boardWidth = 4
    let TileWinValue = 2048
    
    var delegate: GameLogicHandlerDelegate?
    var tiles = [Tile]()
    var countingPoints = 0
    var update: Bool = false
    
    func prepare() {
        update = false
        tiles.removeAll(keepingCapacity: true)
        for row in 0..<boardWidth {
            for column in 0..<boardWidth {
                tiles.append(Tile(position: Position(x: row, y: column)))
            }
        }
        refreshNeighborTiles()
    }
    
    func startGame() {
        countingPoints = 0
        prepare()
        
        delegate?.gameLogicHandlerDidAddTile(addRandomTile())
        delegate?.gameLogicHandlerDidAddTile(addRandomTile())
    }
//function used when shifting wait for update and then slide the other tiles
    func shift(_ direction: ShiftDirections) {
        if update == true { return }
        update = true
        var waitForSignalToContinue = false
        var performedShift = false
        for rowOrColumn in 0..<boardWidth {
            var tilesToCheck = tiles.filter {
                return ((direction == .right || direction == .left) ? $0.position.y : $0.position.x) == rowOrColumn
            }
            
            // when right or down arrow need to be reversed
            if direction == .right || direction == .down {
                tilesToCheck = tilesToCheck.reversed()
            }
            
            var tileIndex = 0
            while tileIndex < tilesToCheck.count {
                let currentTile = tilesToCheck[tileIndex]

                let filter: ((_ tile: Tile) -> Bool) = { tile in
                    let position: Bool = {
                        switch direction {
                        case .up: return tile.position.y > currentTile.position.y
                        case .right: return tile.position.x < currentTile.position.x
                        case .down: return tile.position.y < currentTile.position.y
                        case .left: return tile.position.x > currentTile.position.x
                        }
                    }()
                    
                    return position == true && tile.value != nil
                }
                
                if let otherTile = tilesToCheck.filter(filter).first {
                    // when value added to other remove the other one
                    if otherTile.value == currentTile.value {
                        waitForSignalToContinue = true
                        slideOnSameTile(otherTile, onTile: currentTile)
                        // counting points indicates the value increase
                        countingPoints += currentTile.value!
                        // ends the game when current tile gests wining score
                        if currentTile.value! == TileWinValue {
                            delegate?.gameLogicHandlerDidWinGame()
                            return
                        }
                        delegate?.gameLogicHandlerDidCountPoints(countingPoints)
                        performedShift = true
                    } else if currentTile.value == nil {
                        waitForSignalToContinue = true
                        slideOnEmptyTile(otherTile, destinationTile: currentTile)
                        //repeates when tile slides to other
                        tileIndex -= 1
                        performedShift = true
                    }
                }
                tileIndex += 1
            }
        }
        
        // Every shift method returns boolean value if shift has been performed on
        // some at least one tile or not.
        if performedShift {
            delegate?.gameLogicHandlerDidAddTile(addRandomTile())
        }
        
        if isGameOver() == true { delegate?.gameLogicHandlerDidGameOver() }
        
        if waitForSignalToContinue == false {
            update = false
        }
    }
    
    func slideOnSameTile(_ sourceTile: Tile, onTile destinationTile: Tile) {
        destinationTile.value! *= 2
        sourceTile.value = nil
        delegate?.gameLogicHandlerDidMoveTile(sourceTile, onTile: destinationTile) {
            self.update = false
        }
    }
    
    
     func slideOnEmptyTile(_ sourceTile: Tile, destinationTile: Tile) {
        destinationTile.value = sourceTile.value
        sourceTile.value = nil
        delegate?.gameLogicHandlerDidMoveTile(sourceTile, position: destinationTile.position) {
            self.update = false
        }
    }
    
    //calls this function when no tiles are empty and no neighbors have same value tile
    func isGameOver() -> Bool {
        if tiles.filter({$0.value == nil}).count != 0 { return false }
        for tile in tiles {
            let value = tile.value!
            let neighbors = [tile.upTile, tile.rightTile, tile.bottomTile, tile.leftTile].filter { $0?.value == value }
            if neighbors.count != 0 { return false }
        }
        return true
    }
    
    func addRandomTile() -> Tile? {
        // add random tile when found poistion
        if let position = randomPosition() {
            let tile = tileForPosition(position)
            tile.value = 2
            return tile
        }
        return nil
    }
    
    func tileForPosition(_ position: Position) -> Tile {
        return tiles.filter({$0.position == position}).first!
    }
    
   func randomPosition() -> Position? {
        let emptyTiles = tiles.filter({$0.value == nil})
        return emptyTiles[Int(arc4random_uniform(UInt32(emptyTiles.count)))].position
    }
    //refreshed the neighbour everytime when move happens
    func refreshNeighborTiles() {
        let boardRect = CGRect(x: CGFloat(0.0), y: CGFloat(0.0), width: CGFloat(boardWidth), height: CGFloat(boardWidth))
        for tile in tiles {
            let up = Position(x: tile.position.x, y: tile.position.y - 1)
            if boardRect.contains(up.CGPointRepresentation) {
                tile.upTile = tileForPosition(up)
            }
            
            let right = Position(x: tile.position.x + 1, y: tile.position.y)
            if boardRect.contains(right.CGPointRepresentation) {
                tile.rightTile = tileForPosition(right)
            }
            
            let bottom = Position(x: tile.position.x, y: tile.position.y + 1)
            if boardRect.contains(bottom.CGPointRepresentation) {
                tile.bottomTile = tileForPosition(bottom)
            }
            
            let left = Position(x: tile.position.x - 1, y: tile.position.y)
            if boardRect.contains(left.CGPointRepresentation) {
                tile.leftTile = tileForPosition(left)
            }
        }
    }
}

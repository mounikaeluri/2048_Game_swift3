//
//  TileViewData.swift
//  PuzzleImplementatiomn
//
//  Created by Mounika Eluri on 12/09/16.
//  Copyright © 2016 Mounika Eluri. All rights reserved.
//

import UIKit
//tile view background colors
class TileViewData {
    
    let value: Int
    
    init(value: Int) {
        self.value = value
    }
    
    var valueText: String {
        return "\(value)"
    }
    
    var backgroundColor: UIColor {
        switch value {
        case 2: return UIColor(red:0.99, green:0.5, blue:0.1, alpha:1)
        case 4: return UIColor(red:0.59, green:0.80, blue:0.22, alpha:1)
        case 8: return UIColor(red:0.88, green:0.40, blue:0.73, alpha:1)
        case 16: return UIColor(red:0.44, green:0.50, blue:0.34, alpha:1)
        case 32: return UIColor(red:0.84, green:0.49, blue:0.32, alpha:1)
        case 64: return UIColor(red:0.36, green:0.72, blue:0.84, alpha:1)
        case 128: return UIColor(red:0.26, green:0.74, blue:0.51, alpha:1)
        case 256: return UIColor(red:0.85, green:0.55, blue:0.13, alpha:1)
        case 512: return UIColor(red:0.5, green:0.87, blue:0.53, alpha:1)
        case 1024: return UIColor(red:0.83, green:0.27, blue:0.36, alpha:1)
        case 2048: return UIColor(red:0.9, green:0.66, blue:0.6, alpha:1)
        default: return UIColor.clear         }
    }
}

//
//  ScoreFormatter.swift
//  PuzzleImplementatiomn
//
//  Created by Mounika Eluri on 12/02/16.
//  Copyright © 2016 Mounika Eluri. All rights reserved.
//

import Foundation
import UIKit
//NSMUtableAttributed String to represent score description
extension NSMutableAttributedString {
    
    class func scoreDescription(_ text: String, points: Int) -> NSAttributedString {

        let text = "\(text): \(points)"
        let attributed = NSMutableAttributedString(string: text)
        return attributed
    }
 
}

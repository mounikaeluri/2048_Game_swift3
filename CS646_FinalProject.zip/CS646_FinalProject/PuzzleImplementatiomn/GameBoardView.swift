//
//  GameBoardView.swift
//  PuzzleImplementatiomn
//
//  Created by Mounika Eluri on 12/10/16.
//  Copyright © 2016 Mounika Eluri. All rights reserved.
//

import Foundation
import UIKit
//board view moves start locations new points previous points are handled in this class

protocol GameBoardViewDelegate {
    func gameBoardView(_ view: GameBoardView, didSwipeInDirection direction: ShiftDirections)
}

class GameBoardView: UIView {
    
    var delegate: GameBoardViewDelegate?
    fileprivate var startLocation: CGPoint = CGPoint.zero
    
    override func touchesBegan(_ touches: Set<UITouch>,
                               with event: UIEvent?) {
        let touch = touches.first
        startLocation = (touch?.location(in: self))!
    }
    
    override func touchesEnded(_ touches: Set<UITouch>,
                               with event: UIEvent?) {
        let touch = touches.first
        let newPoint = touch?.location(in: self)
        let prevPoint = startLocation
        
        var directionX: ShiftDirections!
        if (newPoint?.x)! > prevPoint.x {
            directionX = .right
        } else {
            directionX = .left
        }
        
        var directionY: ShiftDirections!
        if (newPoint?.y)! > prevPoint.y {
            directionY = .down
        } else {
            directionY = .up
        }
        
        var direction: ShiftDirections!
        if abs((newPoint?.x)! - prevPoint.x) > abs((newPoint?.y)! - prevPoint.y) {
            direction = directionX
        } else {
            direction = directionY
        }
        
        delegate?.gameBoardView(self, didSwipeInDirection: direction)
    }
}

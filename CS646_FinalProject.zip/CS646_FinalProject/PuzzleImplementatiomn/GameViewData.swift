//
//  GameViewData.swift
//  PuzzleImplementatiomn
//
//  Created by Mounika Eluri on 12/06/16.
//  Copyright © 2016 Mounika Eluri. All rights reserved.
//

import Foundation

class GameViewData {
    
    func bestScoreText(_ points: Int) -> NSAttributedString {
        return NSMutableAttributedString.scoreDescription("HighScore", points: points)
    }
    
    func scoreText(_ points: Int) -> NSAttributedString {
        return NSMutableAttributedString.scoreDescription("Score", points: points)
    }
}

//
//  Tile.swift
//  PuzzleImplementatiomn
//
//  Created by Mounika Eluri on 12/07/16.
//  Copyright © 2016 Mounika Eluri. All rights reserved.
//


import Foundation
import CoreGraphics

func == (lhs: Position, rhs: Position) -> Bool {
    return lhs.x == rhs.x && lhs.y == rhs.y
}

struct Position: Equatable {
    var x, y: Int
    
    var CGPointRepresentation: CGPoint {
        return CGPoint(x: CGFloat(x), y: CGFloat(y))
    }
}

class Tile {
    let position: Position
    var value: Int?
    
    var upTile: Tile?
    var rightTile: Tile?
    var bottomTile: Tile?
    var leftTile: Tile?
    
    init(position: Position, value: Int? = nil) {
        self.position = position
        self.value = value
    }
}

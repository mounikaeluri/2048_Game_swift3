//
//  GameViewController.swift
//  PuzzleImplementatiomn
//
//  Created by Mounika Eluri on 12/04/16.
//  Copyright © 2016 Mounika Eluri. All rights reserved.
//

import UIKit
//import coredata for storage
import CoreData
// import Audio  foundation
import AVFoundation

//View Controller which contains game
class GameViewController : UIViewController,GameLogicHandlerDelegate,
 GameBoardViewDelegate  {
    
  //UserDefaults used to store highscore and username
    let userDefaults = UserDefaults.standard
    
   //variables used to for score highscore and display name
    var people: [NSManagedObject] = []
    var namelabelText = String()
    var DisplayUserName = ""
    var Score: Int = 0
    var Win: Bool = false
    var highScore: Int = 0
    var musicplayer : AVAudioPlayer = AVAudioPlayer()

    
    let gameHandler = GameLogicHandler()
    let viewModel = GameViewData()
    var Apperance: GameBoardApperance!
    
  //names for labels in storyboard
    @IBOutlet var NameLabel: UILabel!
    @IBOutlet var highscoreLabel: UILabel!
    @IBOutlet var scoreLabel: UILabel!
    @IBOutlet var restartbuttonLabel: UIButton!
    @IBOutlet var finishbuttonLabel: UIButton!
    @IBOutlet weak var Topplayerbutton: UIButton!
    
    @IBAction func Topplayer(_ sender: AnyObject) {
        
    }

    @IBOutlet var BoardView: GameBoardView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        BoardView.delegate = self
        Apperance = GameBoardApperance(boardView: BoardView)
        gameHandler.delegate = self
        gameHandler.startGame()
        DisplayUserName = namelabelText
        
        userdefault()
        song()
        
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        updateScores()
    }
    
    //function used for game over
    func gameOver() {
        let alertController = UIAlertController(title: "Game Over", message: "Your Score \n\(Score)", preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "TryAgain", style: .cancel, handler: { _ in self.restart() }))
        alertController.addAction(UIAlertAction(title: "Home", style: .default, handler: { _ in self.finishyes() }))
        alertController.setValue(NSAttributedString(string: "Your Score \n\(Score)", attributes: [NSFontAttributeName : UIFont.systemFont(ofSize: 17),NSForegroundColorAttributeName : UIColor.blue]), forKey: "attributedMessage")
        self.present(alertController, animated: true, completion: nil)

      storagecoredata()

    }
    
    //function to go back to homeviewcontroller
    func finishyes() {
       UIApplication.shared.keyWindow?.rootViewController?.dismiss(animated: true, completion: nil)
    }
    
    //function used when user wins game
     func userWin() {
        Win = true
       
        let alertController = UIAlertController(title: "Victory!!", message: "Your Score \n\(Score)", preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "GoBack", style: .cancel, handler: { _ in self.restart() }))
        alertController.addAction(UIAlertAction(title: "Home", style: .default, handler: { _ in self.finishyes() }))
        self.present(alertController, animated: true, completion: nil)
    }
    
    //function for updatingscore
    func updateScores() {
        scoreLabel.attributedText = viewModel.scoreText(Score)
        highscoreLabel.attributedText = viewModel.bestScoreText(highScore)
        
        userDefaults.setValue(highScore, forKey: "HIGHSCORE")
        print(highscoreLabel.text)
        print(highScore)
        
    }
    
    //function to restart
    func restart() {
        Apperance.reset()
        Score = 0
        updateScores()
        gameHandler.startGame()
    }
    
    //Restart Button action
    @IBAction func RestartButton(_ sender: AnyObject) {
        let alertController = UIAlertController(title: "Restart Game", message: "Are you sure?", preferredStyle: .alert)
        let backView = alertController.view.subviews.last?.subviews.last
        backView?.layer.cornerRadius = 10.0
          alertController.setValue(NSAttributedString(string: "Are you sure", attributes: [NSFontAttributeName : UIFont.systemFont(ofSize: 17),NSForegroundColorAttributeName : UIColor.red]), forKey: "attributedMessage")
        alertController.addAction(UIAlertAction(title: "No", style: .cancel, handler: nil))
        alertController.addAction(UIAlertAction(title: "Yes", style: .default, handler: { _ in self.restart() }))
        self.present(alertController, animated: true, completion: nil)
    }
    
    //finish button action
    @IBAction func FinishButton(_ sender: AnyObject) {
       let alertController = UIAlertController(title: "Finish Game", message: "Are you sure?", preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "No", style: .cancel, handler: nil))
        alertController.addAction(UIAlertAction(title: "Yes", style: .default, handler: { _ in self.gameOver() }))
        alertController.setValue(NSAttributedString(string: "Are you sure", attributes: [NSFontAttributeName : UIFont.systemFont(ofSize: 17),NSForegroundColorAttributeName : UIColor.red]), forKey: "attributedMessage")
        
        self.present(alertController, animated: true, completion: nil)
        
    }
    
    func gameBoardView(_ view: GameBoardView, didSwipeInDirection direction: ShiftDirections) {
        gameHandler.shift(direction)
    }
    
    //GameLogicHandlerDelegate
    func gameLogicHandlerDidAddTile(_ tile: Tile?) {
        if let tile = tile { Apperance.addTile(tile) }
    }
    
    func gameLogicHandlerDidMoveTile(_ sourceTile: Tile, onTile destinationTile: Tile, completionBlock:   @escaping (Void) -> Void) {
        Apperance.moveTile(sourceTile, onTile: destinationTile, completionBlock: completionBlock)
    }
    
    func gameLogicHandlerDidMoveTile(_ tile: Tile, position: Position,  completionBlock:  @escaping (Void) -> Void) {
        Apperance.moveTile(tile, position: position, completionBlock: completionBlock)
    }
    
    func gameLogicHandlerDidCountPoints(_ points: Int) {
        Score = points
    if highScore < points { highScore = points }
        updateScores()
    }
    
    func gameLogicHandlerDidGameOver() {
        gameOver()
    }
    
    func gameLogicHandlerDidWinGame() {
        userWin()
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     //   let NextViewController: PlayerViewController = segue.destination as! PlayerViewController
         
       
    }
    
    //////functions used for storing data in core data and userdefaults as needed
    
    
    //function to store userdefaults
    func userdefault(){
        userDefaults.setValue(DisplayUserName, forKey: "USERNAME")
        
        if userDefaults.value(forKey: "HIGHSCORE") != nil {
            
            highScore = userDefaults.value(forKey: "HIGHSCORE") as! Int
            
            highscoreLabel.text = "HighScore: \(highScore)"
            
            
            print("High Score: \(highScore) ")
        }
        
        if userDefaults.value(forKey: "USERNAME") != nil {
            DisplayUserName = userDefaults.value(forKey: "USERNAME") as! String
            NameLabel.text = "Hello \(DisplayUserName)"
            
            print("UserName: \(DisplayUserName) ")
        }
    }
    //function used to store core data
    func storagecoredata(){
        let nameToSave = " Name :\(DisplayUserName), Score: \(Score)"
        self.save(storage: nameToSave)
    }
//save data in storage attribute
   func save(storage:String) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
  
        let entity = NSEntityDescription.entity(forEntityName: "Game",
                                                in: managedContext)!
        
        let person = NSManagedObject(entity: entity,
                                     insertInto: managedContext)
    
        person.setValue(storage, forKeyPath: "storage")
    
        do {
            try managedContext.save()
        people.append(person)
        } catch let error as NSError {
            print("Could not save. \(error), \(error.userInfo)")
        }
    }
    
    
    ////////////////Song and Sharing buttons and functions used ///////////////////
    
    
    //button used to play music
    @IBOutlet weak var musicLabel: UILabel!
    
    @IBAction func SongPlay(_ sender: AnyObject) {
        musicplayer.play()
        musicLabel.text = "Music ON"
         musicLabel.isHidden = false
        musicplayer.numberOfLoops = -1
    }
    //button used to stop music
    @IBAction func SongPause(_ sender: AnyObject) {
        musicLabel.isHidden = true
        if musicplayer.isPlaying{
            musicplayer.pause()
        }
        else{
            
        }
        
    }
    func song(){
        do {
            let audioPath = Bundle.main.path(forResource: "music", ofType: "mp3")
            try musicplayer = AVAudioPlayer(contentsOf:NSURL (fileURLWithPath: audioPath!) as URL)
        }
        catch{
            print(error)
        }
        
    }
    
    //Button used to share highscore
    @IBAction func ShareButton(_ sender: AnyObject) {
        
        let shareDetails = UIActivityViewController(activityItems: ["My HighScore :\(highScore)"], applicationActivities: nil)
        shareDetails.popoverPresentationController?.sourceView = self.view
        // present the view controller
        self.present(shareDetails, animated: true, completion: nil)
        
    }

}






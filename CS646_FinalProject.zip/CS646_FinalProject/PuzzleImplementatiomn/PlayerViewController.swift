//
//  PlayerViewController.swift
//  PuzzleImplementatiomn
//
//  Created by Mounika Eluri on 12/18/16.
//  Copyright © 2016 Mounika Eluri. All rights reserved.
//

import Foundation
import UIKit
import CoreData
//Displays players name and there highscores
class PlayerViewController: UIViewController{
    
    //variable to store fetch NSManagedObject
    var Player: [NSManagedObject] = []
    
    //table view outlet
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.register(UITableViewCell.self,
                           forCellReuseIdentifier: "Cell")
     
    }
   // fetch data when view appear from view controller
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Game")
        do {
            Player = try managedContext.fetch(fetchRequest)
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
    }
    //button to go bak to gameviewcontroller
    @IBAction func continueplayer(_ sender: AnyObject) {
        self.presentingViewController?.dismiss(animated: true, completion: nil)
    }
    //button to go backtohome view controller
    @IBAction func homebutton(_ sender: AnyObject) {
        UIApplication.shared.keyWindow?.rootViewController?.dismiss(animated: true, completion: nil)
    }

}


 //Extension for table view
//table view updates only when game over or user presses gameover
extension PlayerViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView,
                   numberOfRowsInSection section: Int) -> Int {
        return Player.count
    }
    
    func tableView(_ tableView: UITableView,
                   cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let person = Player[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell",
                                                 for: indexPath)
        cell.textLabel?.text = person.value(forKeyPath: "storage") as? String
        return cell
    }
}



//
//  ViewController.swift
//  PuzzleImplementatiomn
//
//  Created by Mounika Eluri on 12/02/16.
//  Copyright © 2016 Mounika Eluri. All rights reserved.
//

import UIKit

//First viewcontroller
class HomeViewController: UIViewController,UITextFieldDelegate {
   //user defaults used to store highscore and username
    let userDefaults = UserDefaults.standard

  //  variables used to store highscore and username
    var displayhighScore: Int = 0
    var displayname = ""
    var USERNAME = ""
    //names used for labels username,highscore and textfield where user can enter name
    @IBOutlet weak var usernamelabel: UILabel!
    @IBOutlet fileprivate var highScoreLabel: UILabel!
    @IBOutlet var nameTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.nameTextField.delegate = self
    }
 //receiving highscore and username from userdefaults
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if userDefaults.value(forKey: "HIGHSCORE") != nil {
            
            displayhighScore = userDefaults.value(forKey: "HIGHSCORE") as! Int
            highScoreLabel.text = "HighScore: \(displayhighScore)"
            print(highScoreLabel.text)
        }
        
        if userDefaults.value(forKey: "USERNAME") != nil {
            
            USERNAME = userDefaults.value(forKey: "USERNAME") as! String
            usernamelabel.text = "Hello \(USERNAME)"
            nameTextField.text = "\(USERNAME)"
            print("Name: \(USERNAME)")
        }
        
    }
   // startGame Buttom used for segue
 
    @IBAction func StartGameButton(_ sender: AnyObject) {
    }
    
//hide keyboard when touches outside of keyboard
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
        dataFromTextfield()
    }
    //hide keyboard when press return key in keyboard
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        dataFromTextfield()
        nameTextField.resignFirstResponder()
        return(true)
    }
    //function used to copy data from textfield to name label
    func dataFromTextfield(){
        displayname = nameTextField.text!
        usernamelabel.text = "Hello \(displayname)"
    }
    //connection with next view controller
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let NextViewController: GameViewController = segue.destination as! GameViewController
        NextViewController.namelabelText = nameTextField.text!
    }

}

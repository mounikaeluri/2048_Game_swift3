//
//  GameBoardApperance.swift
//  PuzzleImplementatiomn
//
//  Created by Mounika Eluri on 12/08/16.
//  Copyright © 2016 Mounika Eluri. All rights reserved.
//


import UIKit

class GameBoardApperance {
    
    fileprivate var boardView: GameBoardView?
    fileprivate var tileViews = [TileView]()
    
    init(boardView: GameBoardView) {
        self.boardView = boardView
    }
    
    func reset() {
        for view in tileViews {
            view.removeFromSuperview()
        }
        
        tileViews.removeAll(keepingCapacity: true)
    }
    
    func addTile(_ tile: Tile) {
        let tileView = TileView.createView()
        tileView.position = tile.position
        
        let viewModel = TileViewData(value: tile.value!)
        tileView.valueLabel.text = viewModel.valueText
        tileView.backgroundColor = viewModel.backgroundColor
        tileView.valueLabel.alpha = 0
        
        tileView.frame = CGRect.zero
        tileView.center = centerForTile(tile.position)
        
        boardView!.addSubview(tileView)
        
        UIView.animate(withDuration: 0.2, delay: 0, options: UIViewAnimationOptions.curveEaseOut, animations: {
            var bounds = tileView.bounds
            bounds.size = self.tileSize
            tileView.bounds = bounds
        }) { _ in
            UIView.animate(withDuration: 0.15, animations: {
                tileView.valueLabel.alpha = 1
            })
        }
        
        tileViews.append(tileView)
    }
    
    func moveTile(_ sourceTile: Tile, onTile destinationTile: Tile, completionBlock: @escaping (Void) -> Void) {
        let sourceTileView = tileViews.filter({$0.position == sourceTile.position}).first!
        let destinationTileView = tileViews.filter({$0.position == destinationTile.position}).first!
        boardView?.bringSubview(toFront: sourceTileView)
        
        UIView.animate(withDuration: 0.2, delay: 0, options: UIViewAnimationOptions(), animations: {
            sourceTileView.center = destinationTileView.center
            sourceTileView.position = destinationTile.position
            destinationTileView.alpha = 0
            
            let viewModel = TileViewData(value: destinationTile.value!)
            sourceTileView.valueLabel.text = viewModel.valueText
            sourceTileView.backgroundColor = viewModel.backgroundColor
            
        }) { (finished) -> Void in
            destinationTileView.alpha = 0
            destinationTileView.removeFromSuperview()
            
            let index = self.tileViews.index(of: destinationTileView)
            self.tileViews.remove(at: index!)
            completionBlock()
        }
    }
    
    func moveTile(_ tile: Tile, position: Position, completionBlock: @escaping (Void) -> Void) {
        let tileView = tileViews.filter({$0.position == tile.position}).first!
        UIView.animate(withDuration: 0.2, delay: 0, options: UIViewAnimationOptions(), animations: {
            tileView.center = self.centerForTile(position)
            tileView.position = position
        }) { _ in completionBlock() }
    }
    
    func centerForTile(_ position: Position) -> CGPoint {
        let x = (offset * CGFloat(position.x)) + (tileSize.width * CGFloat(position.x)) + (tileSize.width / 2.0)
        let y = (offset * CGFloat(position.y)) + (tileSize.height * CGFloat(position.y)) + (tileSize.height / 2.0)
        return CGPoint(x: x, y: y)
    }
    
    // offset
    var offset: CGFloat {
        return 8.0
    }
    //tile size
    var tileSize: CGSize {
        return CGSize(width: 55, height: 55)
    }
}

